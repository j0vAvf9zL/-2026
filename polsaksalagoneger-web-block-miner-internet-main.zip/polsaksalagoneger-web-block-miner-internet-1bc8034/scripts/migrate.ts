import {
  DynamoDBClient,
  CreateTableCommand,
  ListTablesCommand,
  waitUntilTableExists,
} from "@aws-sdk/client-dynamodb";
import { GetCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import { TABLE_SCHEMAS, TABLE_NAMES, TableName } from "../lib/schema";
import { docClient } from "../lib/db";
import { searchBlocks } from "../lib/data";
import type { Block } from "../lib/models";

const client = new DynamoDBClient({
  endpoint: process.env.DOCUMENT_API_ENDPOINT,
  region: process.env.DOCUMENT_API_REGION ?? "ru-central1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? "",
  },
});

const TABLES = TABLE_NAMES.map((name) => TABLE_SCHEMAS[name]);

const SEED_BLOCKS: Block[] = searchBlocks.map((block) => ({
  ...block,
  createdAt: new Date("2024-01-15").toISOString(),
  updatedAt: new Date("2024-01-15").toISOString(),
}));

async function migrate() {
  console.log("🔧 Запуск миграций DynamoDB...");

  const { TableNames = [] } = await client.send(new ListTablesCommand({}));

  for (const table of TABLES) {
    if (TableNames.includes(table.name)) {
      console.log(`  ✓ Таблица существует: ${table.name}`);
      continue;
    }

    console.log(`  Создание таблицы: ${table.name}...`);

    await client.send(
      new CreateTableCommand({
        TableName: table.name,
        KeySchema: table.keySchema,
        AttributeDefinitions: table.attributeDefinitions,
        ...(table.globalSecondaryIndexes?.length
          ? { GlobalSecondaryIndexes: table.globalSecondaryIndexes }
          : {}),
        BillingMode: "PAY_PER_REQUEST",
      })
    );

    console.log(`  Ожидание активации ${table.name}...`);
    await waitUntilTableExists(
      { client, maxWaitTime: 120 },
      { TableName: table.name }
    );

    console.log(`  ✓ Создана: ${table.name}`);
  }

  await seedBlocks();

  console.log("🎉 Миграции завершены!");
}

async function seedBlocks() {
  console.log("🌱 Посев базовых блоков...");

  for (const block of SEED_BLOCKS) {
    const existing = await docClient.send(
      new GetCommand({
        TableName: TableName.BLOCKS,
        Key: { id: block.id },
      })
    );

    if (existing.Item) {
      console.log(`  • Уже есть: ${block.name}`);
      continue;
    }

    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: block,
      })
    );
    console.log(`  ✓ Добавлен блок: ${block.name}`);
  }

  console.log("🎉 Посев завершён!");
}

migrate().catch((e) => {
  console.error("❌ Ошибка миграции:", e);
  process.exit(1);
});
