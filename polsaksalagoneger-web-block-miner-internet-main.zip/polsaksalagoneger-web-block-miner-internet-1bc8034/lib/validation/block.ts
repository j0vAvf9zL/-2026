import { z } from "zod";

export const blockSectionSchema = z.object({
  heading: z
    .string()
    .trim()
    .min(1, "Укажите тему фрагмента")
    .max(120, "Тема слишком длинная — оставьте до 120 символов"),
  content: z
    .string()
    .trim()
    .min(1, "Добавьте текст или опишите тему в нескольких словах")
    .max(4000, "Фрагмент слишком длинный — оставьте до 4000 символов"),
});

export const addBlockSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, "Укажите название сайта")
    .max(120, "Название слишком длинное — оставьте до 120 символов"),
  url: z
    .string()
    .trim()
    .url("Похоже, это не адрес сайта. Например: https://example.com")
    .max(300, "Адрес слишком длинный"),
  description: z
    .string()
    .trim()
    .max(600, "Описание слишком длинное — оставьте до 600 символов")
    .optional(),
  sections: z
    .array(blockSectionSchema)
    .min(1, "Добавьте хотя бы одну тему или фрагмент")
    .max(12, "Многовато тем — оставьте самые важные"),
});

export type BlockSectionInput = z.infer<typeof blockSectionSchema>;
export type AddBlockValues = z.infer<typeof addBlockSchema>;

export function normalizeBlockUrl(url: string): string {
  const trimmed = url.trim();
  if (!trimmed) return trimmed;
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}
