import { BookOpen, Compass, Newspaper } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardTitle,
} from "@/components/ui/card";
import { BlockNetwork } from "@/components/block-network";

const categories = [
  {
    icon: BookOpen,
    title: "Рецепты и кулинария",
    description: "Пошаговые рецепты из любимых кулинарных сайтов-блоков.",
    iconClass: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  },
  {
    icon: Newspaper,
    title: "Новости и статьи",
    description: "Актуальные публикации районных и тематических блоков.",
    iconClass: "bg-sky-500/10 text-sky-600 dark:text-sky-400",
  },
  {
    icon: Compass,
    title: "Справочники и инструкции",
    description: "Ответы на бытовые вопросы — коротко и по делу.",
    iconClass: "bg-teal-500/10 text-teal-600 dark:text-teal-400",
  },
];

export default function HomePage() {
  return (
    <div>
      <BlockNetwork />

      <section className="mx-auto max-w-5xl px-4 py-16 sm:py-20">
        <div className="mb-10 space-y-2 text-center">
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Что можно найти в блоках
          </h2>
          <p className="text-muted-foreground">
            Пара примеров, чтобы было проще представить.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          {categories.map(({ icon: Icon, title, description, iconClass }) => (
            <Card key={title} className="card-hover rounded-2xl">
              <CardContent className="space-y-4 pt-4">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-xl ${iconClass}`}
                >
                  <Icon className="h-6 w-6" />
                </div>
                <CardTitle className="text-lg">{title}</CardTitle>
                <CardDescription className="leading-relaxed">
                  {description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
