import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getAllBlocks, createBlock } from "@/lib/models";
import { mockBlocks } from "@/lib/mock-data";
import { addBlockSchema, normalizeBlockUrl } from "@/lib/validation/block";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      const blocks = await getAllBlocks();
      return NextResponse.json(blocks);
    } catch (error) {
      console.error("Ошибка получения блоков:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json(mockBlocks);
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "Сохранение недоступно — база данных не подключена" },
      { status: 503 }
    );
  }

  try {
    const body = await request.json();

    if (typeof body !== "object" || body === null || Array.isArray(body)) {
      return NextResponse.json(
        { error: "Некорректные данные" },
        { status: 400 }
      );
    }

    const normalized = {
      ...body,
      url: normalizeBlockUrl(typeof body.url === "string" ? body.url : ""),
    };

    const parsed = addBlockSchema.safeParse(normalized);

    if (!parsed.success) {
      return NextResponse.json(
        {
          error: "Некорректные данные",
          details: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }

    const block = await createBlock({
      name: parsed.data.name,
      url: parsed.data.url,
      description: parsed.data.description ?? "",
      sections: parsed.data.sections,
    });

    return NextResponse.json(block, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания блока:", error);
    return NextResponse.json(
      { error: "Ошибка сохранения блока" },
      { status: 500 }
    );
  }
}
