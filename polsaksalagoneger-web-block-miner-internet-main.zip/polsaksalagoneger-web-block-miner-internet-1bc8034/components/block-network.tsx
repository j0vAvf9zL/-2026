"use client";

import { useCallback, useEffect, useState } from "react";
import { BlockSearch } from "@/components/block-search";
import { AddBlockDialog } from "@/components/add-block-dialog";
import { BlockCardDialog } from "@/components/block-card-dialog";
import { NetworkList } from "@/components/network-list";
import { type SearchBlock } from "@/lib/data";

export function BlockNetwork() {
  const [blocks, setBlocks] = useState<SearchBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBlock, setSelectedBlock] = useState<SearchBlock | null>(null);

  const loadBlocks = useCallback(async () => {
    try {
      const response = await fetch("/api/blocks");
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data: unknown = await response.json();
      setBlocks(Array.isArray(data) ? (data as SearchBlock[]) : []);
    } catch (error) {
      console.error("Ошибка загрузки блоков:", error);
      setBlocks([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadBlocks();
  }, [loadBlocks]);

  const handleSaved = useCallback((block: SearchBlock) => {
    setBlocks((prev) => [
      block,
      ...prev.filter((item) => item.id !== block.id),
    ]);
  }, []);

  return (
    <>
      <section className="gradient-hero-mint border-b">
        <div className="mx-auto max-w-3xl px-4 py-20 text-center sm:py-28">
          <BlockSearch
            blocks={blocks}
            loading={loading}
            onOpenBlock={setSelectedBlock}
          />
          <AddBlockDialog onSaved={handleSaved} />
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-16 sm:py-20">
        <NetworkList
          blocks={blocks}
          loading={loading}
          onOpenBlock={setSelectedBlock}
        />
      </section>

      <BlockCardDialog
        block={selectedBlock}
        onClose={() => setSelectedBlock(null)}
      />
    </>
  );
}
