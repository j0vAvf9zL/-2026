"use client";

import { useState } from "react";
import { ListPlus, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  addBlockSchema,
  normalizeBlockUrl,
  type BlockSectionInput,
} from "@/lib/validation/block";
import { type SearchBlock } from "@/lib/data";

const MAX_SECTIONS = 12;

const INITIAL_SECTION: BlockSectionInput = { heading: "", content: "" };

type FieldErrors = Record<string, string>;

type AddBlockDialogProps = {
  onSaved?: (block: SearchBlock) => void;
};

export function AddBlockDialog({ onSaved }: AddBlockDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [description, setDescription] = useState("");
  const [sections, setSections] = useState<BlockSectionInput[]>([
    { ...INITIAL_SECTION },
  ]);
  const [errors, setErrors] = useState<FieldErrors>({});

  const clearError = (path: string) => {
    setErrors((prev) => {
      if (!prev[path]) return prev;
      const next = { ...prev };
      delete next[path];
      return next;
    });
  };

  const resetForm = () => {
    setName("");
    setUrl("");
    setDescription("");
    setSections([{ ...INITIAL_SECTION }]);
    setErrors({});
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) resetForm();
  };

  const updateSection = (
    index: number,
    field: keyof BlockSectionInput,
    value: string
  ) => {
    setSections((prev) =>
      prev.map((section, i) =>
        i === index ? { ...section, [field]: value } : section
      )
    );
    clearError(`sections.${index}.${field}`);
  };

  const addSection = () => {
    setSections((prev) =>
      prev.length < MAX_SECTIONS ? [...prev, { ...INITIAL_SECTION }] : prev
    );
  };

  const removeSection = (index: number) => {
    setSections((prev) =>
      prev.length === 1 ? prev : prev.filter((_, i) => i !== index)
    );
    setErrors((prev) => {
      const next = { ...prev };
      delete next[`sections.${index}.heading`];
      delete next[`sections.${index}.content`];
      return next;
    });
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const preparedUrl = normalizeBlockUrl(url);

    const result = addBlockSchema.safeParse({
      name,
      url: preparedUrl,
      description,
      sections,
    });

    if (!result.success) {
      const next: FieldErrors = {};
      for (const issue of result.error.issues) {
        const path = issue.path.join(".");
        if (!next[path]) next[path] = issue.message;
      }
      setErrors(next);
      setUrl(preparedUrl);
      toast.error("Проверьте выделенные поля");
      return;
    }

    const loadingId = toast.loading("Сохраняем блок...");

    try {
      const response = await fetch("/api/blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(result.data),
      });

      if (!response.ok) {
        const data: {
          error?: string;
          details?: { fieldErrors?: Record<string, string[] | undefined> };
        } | null = await response.json().catch(() => null);

        if (response.status === 400 && data?.details?.fieldErrors) {
          const next: FieldErrors = {};
          for (const [key, messages] of Object.entries(
            data.details.fieldErrors
          )) {
            const first = Array.isArray(messages) ? messages[0] : undefined;
            if (!first) continue;
            next[key === "sections" ? "sections.0.heading" : key] = first;
          }
          setErrors(next);
        }

        toast.error(data?.error ?? "Не удалось сохранить блок", {
          id: loadingId,
        });
        return;
      }

      const saved = (await response.json()) as SearchBlock;
      onSaved?.(saved);
      resetForm();
      setOpen(false);
      toast.success("Блок добавлен в сеть", {
        id: loadingId,
        description: `«${saved.name}» теперь участвует в поиске по своему содержимому.`,
      });
    } catch (error) {
      console.error("Ошибка сохранения блока:", error);
      toast.error("Не удалось сохранить блок. Попробуйте ещё раз.", {
        id: loadingId,
      });
    }
  };

  return (
    <>
      <div className="mt-8 flex justify-center">
        <Button
          type="button"
          variant="outline"
          size="lg"
          onClick={() => setOpen(true)}
          className="h-12 gap-2 rounded-full bg-white/70 ring-1 ring-border backdrop-blur hover:bg-white"
        >
          <Plus className="text-primary" />
          Добавить блок
        </Button>
      </div>

      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto sm:max-w-lg">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="flex flex-col gap-5"
          >
            <DialogHeader>
              <DialogTitle>Добавить блок</DialogTitle>
              <DialogDescription>
                Расскажите о сайте — и он станет частью сети БлокПоиска.
              </DialogDescription>
            </DialogHeader>

            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="block-name">Название сайта</Label>
                <Input
                  id="block-name"
                  value={name}
                  onChange={(event) => {
                    setName(event.target.value);
                    clearError("name");
                  }}
                  placeholder="Например, Уютный дом"
                  aria-invalid={Boolean(errors.name)}
                />
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Название, под которым сайт будет виден в поиске.
                </p>
                {errors.name && (
                  <p className="text-xs font-medium text-destructive">
                    {errors.name}
                  </p>
                )}
              </div>

              <div className="flex flex-col gap-2">
                <Label htmlFor="block-url">Адрес сайта</Label>
                <Input
                  id="block-url"
                  type="url"
                  value={url}
                  onChange={(event) => {
                    setUrl(event.target.value);
                    clearError("url");
                  }}
                  placeholder="https://example.com"
                  aria-invalid={Boolean(errors.url)}
                />
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Полная ссылка на сайт. Протокол можно не указывать — добавим
                  сами.
                </p>
                {errors.url && (
                  <p className="text-xs font-medium text-destructive">
                    {errors.url}
                  </p>
                )}
              </div>

              <div className="flex flex-col gap-2">
                <Label htmlFor="block-description">Описание</Label>
                <Textarea
                  id="block-description"
                  rows={3}
                  value={description}
                  onChange={(event) => {
                    setDescription(event.target.value);
                    clearError("description");
                  }}
                  placeholder="Пара предложений о сайте и его аудитории"
                  aria-invalid={Boolean(errors.description)}
                />
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Короткое описание сайта — оно появится на карточке результата.
                  Не обязательно.
                </p>
                {errors.description && (
                  <p className="text-xs font-medium text-destructive">
                    {errors.description}
                  </p>
                )}
              </div>

              <Separator />

              <div className="flex flex-col gap-3">
                <div className="flex flex-col gap-1">
                  <h3 className="text-sm font-medium">Содержимое блока</h3>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Ключевые темы или фрагменты текста сайта — по ним блок будет
                    находиться в поиске. Добавьте хотя бы одну тему.
                  </p>
                </div>

                {sections.map((section, index) => {
                  const headingError = errors[`sections.${index}.heading`];
                  const contentError = errors[`sections.${index}.content`];
                  return (
                    <div
                      key={index}
                      className="flex flex-col gap-3 rounded-xl bg-muted/40 p-3 ring-1 ring-border/60"
                    >
                      <div className="flex flex-col gap-2">
                        <Label htmlFor={`block-section-${index}-heading`}>
                          Тема {index + 1}
                        </Label>
                        <Input
                          id={`block-section-${index}-heading`}
                          value={section.heading}
                          onChange={(event) =>
                            updateSection(index, "heading", event.target.value)
                          }
                          placeholder="Например, Рецепты на завтрак"
                          aria-invalid={Boolean(headingError)}
                        />
                        {headingError && (
                          <p className="text-xs font-medium text-destructive">
                            {headingError}
                          </p>
                        )}
                      </div>

                      <div className="flex flex-col gap-2">
                        <Label htmlFor={`block-section-${index}-content`}>
                          Фрагмент текста
                        </Label>
                        <Textarea
                          id={`block-section-${index}-content`}
                          rows={3}
                          value={section.content}
                          onChange={(event) =>
                            updateSection(index, "content", event.target.value)
                          }
                          placeholder="Короткий фрагмент или несколько слов о теме"
                          aria-invalid={Boolean(contentError)}
                        />
                        {contentError && (
                          <p className="text-xs font-medium text-destructive">
                            {contentError}
                          </p>
                        )}
                      </div>

                      {sections.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeSection(index)}
                          className="self-start gap-1.5 text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="size-4" />
                          Удалить тему
                        </Button>
                      )}
                    </div>
                  );
                })}

                {sections.length < MAX_SECTIONS && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addSection}
                    className="self-start gap-1.5"
                  >
                    <ListPlus className="size-4" />
                    Добавить ещё одну тему
                  </Button>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
              >
                Отмена
              </Button>
              <Button type="submit">Сохранить блок</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
