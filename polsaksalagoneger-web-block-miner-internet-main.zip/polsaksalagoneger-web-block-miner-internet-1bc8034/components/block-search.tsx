"use client";

import { useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  Blocks,
  Globe,
  RotateCcw,
  Search,
  SearchX,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { exampleQueries, type SearchBlock } from "@/lib/data";

const STOPWORDS = new Set([
  "как",
  "что",
  "это",
  "или",
  "и",
  "в",
  "на",
  "с",
  "по",
  "для",
  "из",
  "к",
  "о",
  "об",
  "при",
  "у",
  "за",
  "от",
  "до",
  "про",
  "не",
  "то",
  "же",
  "бы",
  "а",
  "и",
  "где",
  "когда",
  "почему",
  "сколько",
  "какой",
  "какая",
  "какие",
  "можно",
  "нужно",
  "помочь",
  "найти",
]);

type MatchInfo = {
  block: SearchBlock;
  matchedTokens: string[];
  fragment: string | null;
  explanation: string;
};

function normalize(text: string): string {
  return text.toLocaleLowerCase("ru");
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function getSignificantTokens(query: string): string[] {
  const tokens = normalize(query)
    .split(/\s+/)
    .map((token) => token.replace(/[^a-zа-яё0-9]/gi, ""))
    .filter((token) => token.length >= 2 && !STOPWORDS.has(token));
  return Array.from(new Set(tokens));
}

function blockText(block: SearchBlock): string {
  const parts = [block.name, block.description];
  for (const section of block.sections) {
    parts.push(section.heading, section.content);
  }
  return normalize(parts.join(" "));
}

function hasWordWithPrefix(text: string, prefix: string): boolean {
  return new RegExp(`(^|\\s)${escapeRegExp(prefix)}`, "i").test(text);
}

function tokenMatches(text: string, token: string): boolean {
  if (text.includes(token)) return true;
  const prefix = token.slice(0, 5);
  if (prefix.length < 4) return false;
  return hasWordWithPrefix(text, prefix);
}

function earliestTokenIndex(text: string, tokens: string[]): number {
  let min = -1;
  for (const token of tokens) {
    let index = text.indexOf(token);
    if (index === -1) {
      const prefix = token.slice(0, 5);
      if (prefix.length >= 4) {
        const match = text.match(
          new RegExp(`(^|\\s)${escapeRegExp(prefix)}`, "i")
        );
        if (match && match.index !== undefined) {
          index = match.index + match[1].length;
        }
      }
    }
    if (index !== -1 && (min === -1 || index < min)) {
      min = index;
    }
  }
  return min;
}

function extractFragment(content: string, pos: number): string {
  let start = Math.max(0, pos - 70);
  if (start > 0) {
    const space = content.lastIndexOf(" ", start + 30);
    if (space !== -1) start = space + 1;
  }
  let end = Math.min(content.length, pos + 110);
  if (end < content.length) {
    const space = content.indexOf(" ", end);
    if (space !== -1) end = space;
  }
  let fragment = content.slice(start, end).trim();
  if (start > 0) fragment = `… ${fragment}`;
  if (end < content.length) fragment = `${fragment} …`;
  return fragment;
}

function buildMatch(block: SearchBlock, tokens: string[]): MatchInfo {
  const text = blockText(block);
  const matchedTokens = tokens.filter((token) => tokenMatches(text, token));

  let bestHeading: string | null = null;
  let bestContent: string | null = null;
  let bestPos = Infinity;

  for (const section of block.sections) {
    const lowerContent = normalize(section.content);
    const pos = earliestTokenIndex(lowerContent, matchedTokens);
    if (pos !== -1 && pos < bestPos) {
      bestPos = pos;
      bestHeading = section.heading;
      bestContent = section.content;
    }
  }

  const lowerName = normalize(block.name);
  const lowerDescription = normalize(block.description);

  let explanation: string;
  if (bestHeading) {
    explanation = `Найдено в разделе «${bestHeading}» — этот блок содержит информацию, подходящую под запрос.`;
  } else if (
    matchedTokens.some((token) => tokenMatches(lowerDescription, token))
  ) {
    explanation = "Подходит под запрос по описанию блока.";
  } else if (matchedTokens.some((token) => tokenMatches(lowerName, token))) {
    explanation = "Совпадение с запросом в названии блока.";
  } else {
    explanation = "Блок содержит упоминания, близкие к запросу.";
  }

  const fragment = bestContent ? extractFragment(bestContent, bestPos) : null;

  return { block, matchedTokens, fragment, explanation };
}

export function domainOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

function plural(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
}

function Highlighted({ text, tokens }: { text: string; tokens: string[] }) {
  if (tokens.length === 0) {
    return <>{text}</>;
  }
  const pattern = tokens.map(escapeRegExp).join("|");
  const parts = text.split(new RegExp(`(${pattern})`, "giu"));
  return (
    <>
      {parts.map((part, index) =>
        index % 2 === 1 ? (
          <mark
            key={index}
            className="rounded bg-amber-200/70 px-0.5 text-foreground"
          >
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </>
  );
}

type BlockSearchProps = {
  blocks: SearchBlock[];
  loading: boolean;
  onOpenBlock: (block: SearchBlock) => void;
};

export function BlockSearch({
  blocks,
  loading,
  onOpenBlock,
}: BlockSearchProps) {
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => {
    const tokens = getSignificantTokens(submittedQuery);
    if (tokens.length === 0) return [];
    return blocks
      .map((block) => buildMatch(block, tokens))
      .filter((match) => match.matchedTokens.length > 0)
      .sort((a, b) => b.matchedTokens.length - a.matchedTokens.length);
  }, [submittedQuery, blocks]);

  const hasQuery = submittedQuery.trim().length > 0;

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmittedQuery(query);
    if (query.trim().length === 0) {
      inputRef.current?.focus();
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 space-y-8">
      <div className="inline-flex items-center gap-2 rounded-full bg-white/70 px-4 py-1.5 text-sm font-medium text-foreground shadow-sm ring-1 ring-border backdrop-blur">
        <Blocks className="h-4 w-4 text-primary" />
        Бета · поиск по блокам интернета
      </div>

      <div className="space-y-4">
        <h1 className="text-5xl font-bold tracking-tight sm:text-6xl">
          БлокПоиск
        </h1>
        <p className="mx-auto max-w-xl text-lg leading-relaxed text-muted-foreground sm:text-xl">
          Помогаем находить нужную информацию на сайтах, объединённых в блоки
          единой сети. Введите запрос — и мы подскажем, где это есть.
        </p>
      </div>

      <form
        role="search"
        onSubmit={handleSubmit}
        className="mx-auto flex max-w-2xl items-center gap-2 rounded-full bg-card p-2 pl-5 shadow-lg ring-1 ring-border"
      >
        <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Например, рецепт сырников или расписание электричек"
          aria-label="Поиск по блокам"
          className="h-12 border-0 bg-transparent px-0 text-base shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
        />
        <Button
          type="submit"
          size="lg"
          className="h-12 shrink-0 rounded-full px-6"
        >
          Найти
        </Button>
      </form>

      <div className="flex flex-wrap items-center justify-center gap-2">
        <span className="text-sm text-muted-foreground">
          Попробуйте спросить:
        </span>
        {exampleQueries.map((example) => (
          <button
            key={example}
            type="button"
            onClick={() => {
              setQuery(example);
              setSubmittedQuery(example);
            }}
            className="cursor-pointer rounded-full bg-white/70 px-4 py-1.5 text-sm font-medium text-foreground ring-1 ring-border transition-colors hover:bg-white"
          >
            {example}
          </button>
        ))}
      </div>

      {hasQuery && (
        <div className="space-y-4 text-left">
          {loading ? (
            <div className="mx-auto max-w-2xl space-y-3">
              <Skeleton className="mx-auto h-5 w-64 rounded-full" />
              <Skeleton className="h-36 w-full rounded-2xl" />
              <Skeleton className="h-36 w-full rounded-2xl" />
            </div>
          ) : results.length > 0 ? (
            <>
              <p className="text-center text-sm text-muted-foreground">
                Нашли {results.length}{" "}
                {plural(
                  results.length,
                  "подходящий блок",
                  "подходящих блока",
                  "подходящих блоков"
                )}{" "}
                по запросу «{submittedQuery}»
              </p>
              <div className="space-y-4">
                {results.map((match) => (
                  <Card
                    key={match.block.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => onOpenBlock(match.block)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        onOpenBlock(match.block);
                      }
                    }}
                    className="card-hover cursor-pointer rounded-2xl transition-shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between gap-3">
                        <CardTitle className="text-lg">
                          <Highlighted
                            text={match.block.name}
                            tokens={match.matchedTokens}
                          />
                        </CardTitle>
                        <span className="inline-flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                          <Globe className="h-3.5 w-3.5" />
                          {domainOf(match.block.url)}
                        </span>
                      </div>
                      <CardDescription className="leading-relaxed">
                        <Highlighted
                          text={match.block.description}
                          tokens={match.matchedTokens}
                        />
                      </CardDescription>
                    </CardHeader>
                    {match.fragment && (
                      <CardContent className="space-y-3">
                        <blockquote className="rounded-xl bg-muted/60 px-4 py-3 text-sm leading-relaxed text-foreground ring-1 ring-border/60">
                          <Highlighted
                            text={match.fragment}
                            tokens={match.matchedTokens}
                          />
                        </blockquote>
                        <p className="flex items-start gap-2 text-sm text-muted-foreground">
                          <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                          <span>{match.explanation}</span>
                        </p>
                      </CardContent>
                    )}
                    <CardFooter>
                      <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
                        Открыть карточку
                        <ArrowUpRight className="h-4 w-4" />
                      </span>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 mx-auto max-w-xl space-y-5">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-muted/80 ring-1 ring-border">
                <SearchX className="h-6 w-6 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-semibold tracking-tight">
                  По запросу «{submittedQuery}» ничего не нашлось
                </h2>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Попробуйте сформулировать запрос иначе — короче и проще — или
                  выберите один из примеров выше, чтобы найти что-то новое.
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                className="rounded-full"
                onClick={() => {
                  setQuery("");
                  setSubmittedQuery("");
                  inputRef.current?.focus();
                }}
              >
                <RotateCcw className="h-4 w-4" />
                Начать новый поиск
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
