"use client";

import { Blocks, Globe } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { type SearchBlock } from "@/lib/data";
import { domainOf } from "@/components/block-search";

type NetworkListProps = {
  blocks: SearchBlock[];
  loading: boolean;
  onOpenBlock: (block: SearchBlock) => void;
};

export function NetworkList({
  blocks,
  loading,
  onOpenBlock,
}: NetworkListProps) {
  return (
    <div className="space-y-8">
      <div className="mb-6 space-y-2 text-center">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Сайты в сети
        </h2>
        <p className="text-muted-foreground">
          Все блоки, которые участвуют в поиске БлокПоиска.
        </p>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <Skeleton key={index} className="h-28 rounded-2xl" />
          ))}
        </div>
      ) : blocks.length === 0 ? (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 mx-auto max-w-xl space-y-5">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-muted/80 ring-1 ring-border">
            <Blocks className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="space-y-2 text-center">
            <h3 className="text-xl font-semibold tracking-tight">
              В сети пока нет блоков
            </h3>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Нажмите кнопку «Добавить блок», чтобы добавить первый сайт в сеть.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {blocks.map((block) => (
            <Card
              key={block.id}
              role="button"
              tabIndex={0}
              onClick={() => onOpenBlock(block)}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onOpenBlock(block);
                }
              }}
              className="card-hover cursor-pointer rounded-2xl transition-shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
            >
              <CardContent className="space-y-2 pt-4">
                <div className="flex items-center justify-between gap-3">
                  <CardTitle className="text-lg">{block.name}</CardTitle>
                  <span className="inline-flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                    <Globe className="h-3.5 w-3.5" />
                    {domainOf(block.url)}
                  </span>
                </div>
                <CardDescription className="line-clamp-2 leading-relaxed">
                  {block.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
