"use client";

import { ExternalLink, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { type SearchBlock } from "@/lib/data";
import { domainOf } from "@/components/block-search";

type BlockCardDialogProps = {
  block: SearchBlock | null;
  onClose: () => void;
};

export function BlockCardDialog({ block, onClose }: BlockCardDialogProps) {
  return (
    <Dialog
      open={block !== null}
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      {block && (
        <DialogContent className="max-h-[85dvh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg leading-snug">
              {block.name}
            </DialogTitle>
            <DialogDescription className="leading-relaxed">
              {block.description}
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-4">
            <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <Globe className="h-3.5 w-3.5" />
              {domainOf(block.url)}
            </span>

            <div className="flex flex-col gap-3">
              {block.sections.map((section) => (
                <div
                  key={section.heading}
                  className="rounded-xl bg-muted/60 px-4 py-3 ring-1 ring-border/60"
                >
                  <h3 className="text-sm font-semibold">{section.heading}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {section.content}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <a
              href={block.url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto"
            >
              <Button className="w-full gap-2 sm:w-auto">
                <ExternalLink className="h-4 w-4" />
                Перейти на сайт
              </Button>
            </a>
          </DialogFooter>
        </DialogContent>
      )}
    </Dialog>
  );
}
